from flask import Flask, request, jsonify, render_template
from pymongo import MongoClient
from sklearn.tree import DecisionTreeClassifier
import numpy as np

app = Flask(__name__)

# MongoDB setup
client = MongoClient('mongodb://localhost:27017/')
db = client.admin

# Dummy data for machine learning
X = np.array([[1, 1, 0, 0],  # Flu
              [1, 0, 1, 0],  # Cold
              [0, 1, 0, 1],  # Migraine
              [0, 0, 0, 0]]) # Healthy
y = np.array(["Flu", "Cold", "Migraine", "Healthy"])
symptom_department_map = {
    "fever": "General Medicine",
    "fatigue": "General Medicine",
    "cough": "Pulmonology",
    "headache": "Neurology",
    "excessive bleeding during menstruation": "Obstetrics and Gynecology",
    "chest pain": "Cardiology",
    "shortness of breath": "Pulmonology",
    "abdominal pain": "Gastroenterology",
    "skin rash": "Dermatology",
    "joint pain": "Rheumatology"
}

# Train a simple decision tree classifier
clf = DecisionTreeClassifier()
clf.fit(X, y)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/api/symptom-assessment', methods=['POST'])
def assess_symptoms():
    symptoms = request.json
    # Simple encoding for symptoms
    fever = 1 if 'fever' in symptoms else 0
    fatigue = 1 if 'fatigue' in symptoms else 0
    cough = 1 if 'cough' in symptoms else 0
    headache = 1 if 'headache' in symptoms else 0
    excessive_bleeding = 1 if 'excessive bleeding during menstruation' in symptoms else 0
    
    # Predict diagnosis
    prediction = clf.predict([[fever, fatigue, cough, headache]])
    
    # Get the related department for the symptoms
    departments = []
    for symptom in symptoms:
        department = symptom_department_map.get(symptom.strip().lower(), "General")
        if department not in departments:
            departments.append(department)

    return jsonify({
        "diagnosis": prediction[0],
        "related_departments": departments
    }), 200


@app.route('/api/users', methods=['POST'])
def create_user():
    user_data = request.json
    db.users.insert_one(user_data)
    return jsonify({"message": "User created successfully!"}), 201

@app.route('/api/users/<user_id>/advice', methods=['GET'])
def get_medical_advice(user_id):
    user = db.users.find_one({"_id": user_id})
    symptoms = user.get("symptoms", [])
    
    # Personalized advice logic based on symptoms
    advice = []
    if 'fever' in symptoms:
        advice.append("Stay hydrated and rest.")
    if 'fatigue' in symptoms:
        advice.append("Consider light exercise and proper nutrition.")
    
    return jsonify({"advice": advice}), 200

@app.route('/api/appointments', methods=['POST'])
def add_appointment():
    data = request.json
    result = db.appointments.insert_one(data)
    return jsonify({"_id": str(result.inserted_id)}), 201

@app.route('/api/feedback', methods=['POST'])
def submit_feedback():
    data = request.json
    db.feedback.insert_one(data)
    return jsonify({"message": "Feedback submitted successfully."}), 201

@app.route('/api/health-education', methods=['GET'])
def get_health_articles():
    # Example static articles; replace with real API or scraping
    articles = [
        {"title": "Flu Prevention", "content": "Wash your hands regularly."},
        {"title": "Managing Fatigue", "content": "Ensure adequate sleep."},
    ]
    return jsonify(articles), 200

if __name__ == '__main__':
    app.run(debug=True)
