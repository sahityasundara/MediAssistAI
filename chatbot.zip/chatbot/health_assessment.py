import json
from datetime import datetime, timedelta
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, LabelEncoder

# Predefined symptom dataset (for training the ML model)
data = {
    'fever': 'Flu',
    'cough': 'Cold',
    'headache': 'Migraine',
    'sore throat': 'Tonsillitis',
    'chills': 'Flu',
    'fatigue': 'COVID-19',
    'muscle pain': 'Flu',
    'runny nose': 'Cold',
    'shortness of breath': 'COVID-19',
    'nausea': 'Gastroenteritis',
    'dizziness': 'Vertigo',
}

# Prepare training data for the machine learning model
symptoms = list(data.keys())
diagnoses = list(data.values())

# One-Hot Encoding for symptoms
encoder = OneHotEncoder(sparse_output=False)  # Updated parameter
X = encoder.fit_transform(np.array(symptoms).reshape(-1, 1))  # Encode symptoms

# Create LabelEncoder instance
label_encoder = LabelEncoder()  # Initialize label encoder
y = label_encoder.fit_transform(diagnoses)  # Target variable

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the decision tree classifier
clf = DecisionTreeClassifier()
clf.fit(X_train, y_train)

# Predefined advice with severity levels (can be expanded)
ADVICE = {
    'Flu': {
        'mild': 'Rest and stay hydrated.',
        'moderate': 'Over-the-counter medications can help.',
        'severe': 'Consult a healthcare professional immediately.'
    },
    'Cold': {
        'mild': 'Stay hydrated and use a humidifier.',
        'moderate': 'Consider using cough suppressants.',
        'severe': 'Seek medical attention if persistent.'
    },
    'Migraine': {
        'mild': 'Relax and drink plenty of water.',
        'moderate': 'Use over-the-counter pain relievers.',
        'severe': 'Consult a healthcare professional if severe.'
    },
    'Tonsillitis': {
        'mild': 'Gargle with warm salt water.',
        'moderate': 'Over-the-counter pain relievers can help.',
        'severe': 'Consult a healthcare professional immediately.'
    },
    'COVID-19': {
        'mild': 'Rest and stay hydrated.',
        'moderate': 'Monitor symptoms and consider seeking medical advice.',
        'severe': 'Seek immediate medical attention.'
    },
    'Gastroenteritis': {
        'mild': 'Stay hydrated with clear fluids.',
        'moderate': 'Consider over-the-counter medications.',
        'severe': 'Consult a healthcare professional immediately.'
    },
    'Vertigo': {
        'mild': 'Sit or lie down until symptoms improve.',
        'moderate': 'Consider medication to reduce symptoms.',
        'severe': 'Seek medical attention if persistent.'
    },
}

# Health education resources (can be expanded with real URLs)
HEALTH_EDUCATION = {
    'Flu': 'Learn more about Flu prevention and treatment at [CDC Flu Information](https://www.cdc.gov/flu/).',
    'Cold': 'Find tips for managing a Cold at [Mayo Clinic Cold Information](https://www.mayoclinic.org/).',
    'Migraine': 'Read about Migraine management at [American Migraine Foundation](https://americanmigrainefoundation.org/).',
    'Tonsillitis': 'Tonsillitis treatment options are available at [WebMD Tonsillitis](https://www.webmd.com/).',
    'COVID-19': 'Stay updated on COVID-19 at [WHO COVID-19](https://www.who.int/).',
    'Gastroenteritis': 'Understand Gastroenteritis at [NHS UK Gastroenteritis](https://www.nhs.uk/).',
    'Vertigo': 'Learn about Vertigo treatments at [Vertigo Treatment](https://www.healthline.com/).',
}

# User profiles
user_profiles = {}

def create_user_profile(name, age, medical_history):
    """Create a new user profile."""
    user_profiles[name] = {
        'age': age,
        'medical_history': medical_history,
        'appointments': [],
        'medications': [],
        'symptom_journal': []
    }

def schedule_appointment(name, date, time):
    """Schedule an appointment for a user."""
    if name in user_profiles:
        user_profiles[name]['appointments'].append({
            'date': date,
            'time': time
        })
        print(f"Appointment scheduled for {name} on {date} at {time}.")
    else:
        print("User profile not found.")

def view_appointments(name):
    """View all scheduled appointments for a user."""
    if name in user_profiles:
        appointments = user_profiles[name]['appointments']
        if appointments:
            print(f"Appointments for {name}:")
            for appointment in appointments:
                print(f"- {appointment['date']} at {appointment['time']}")
        else:
            print(f"No appointments scheduled for {name}.")
    else:
        print("User profile not found.")

def cancel_appointment(name, date, time):
    """Cancel an appointment for a user."""
    if name in user_profiles:
        appointments = user_profiles[name]['appointments']
        for appointment in appointments:
            if appointment['date'] == date and appointment['time'] == time:
                appointments.remove(appointment)
                print(f"Appointment on {date} at {time} canceled for {name}.")
                return
        print("Appointment not found.")
    else:
        print("User profile not found.")

def predict_diagnosis(symptom):
    """Predict diagnosis based on the symptom using ML model."""
    symptom_encoded = encoder.transform(np.array([[symptom]]))  # Encode the symptom
    prediction = clf.predict(symptom_encoded)  # Predict diagnosis
    return label_encoder.inverse_transform(prediction)[0]  # Decode the prediction

def provide_advice(diagnosis):
    """Provide advice based on the predicted diagnosis."""
    if diagnosis in ADVICE:
        for severity, message in ADVICE[diagnosis].items():
            print(f"{severity.capitalize()} Advice: {message}")
    else:
        print("No advice available for this diagnosis.")

def log_symptom(name, symptom):
    """Log a symptom for the user."""
    if name in user_profiles:
        user_profiles[name]['symptom_journal'].append({
            'symptom': symptom,
            'date': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        print(f"Symptom '{symptom}' logged for {name}.")
    else:
        print("User profile not found.")

def set_medication_reminder(name, medication, days_until_reminder):
    """Set a medication reminder for the user."""
    if name in user_profiles:
        reminder_date = datetime.now() + timedelta(days=days_until_reminder)
        user_profiles[name]['medications'].append({
            'medication': medication,
            'reminder_date': reminder_date.strftime("%Y-%m-%d %H:%M:%S")
        })
        print(f"Reminder set for {medication} on {user_profiles[name]['medications'][-1]['reminder_date']} for {name}.")
    else:
        print("User profile not found.")

def view_medication_reminders(name):
    """View medication reminders for the user."""
    if name in user_profiles:
        reminders = user_profiles[name]['medications']
        if reminders:
            print(f"Medication reminders for {name}:")
            for reminder in reminders:
                print(f"- {reminder['medication']} on {reminder['reminder_date']}")
        else:
            print(f"No medication reminders for {name}.")
    else:
        print("User profile not found.")

def provide_health_education(diagnosis):
    """Provide health education resources based on diagnosis."""
    if diagnosis in HEALTH_EDUCATION:
        print(f"Health Education: {HEALTH_EDUCATION[diagnosis]}")
    else:
        print("No health education resources available for this diagnosis.")

def save_profiles_to_json(filename='user_profiles.json'):
    """Save user profiles to a JSON file."""
    with open(filename, 'w') as file:
        json.dump(user_profiles, file)
        print("User profiles saved to JSON.")

# Example of usage
if __name__ == "__main__":
    create_user_profile('Alice', 30, 'No major illnesses')
    log_symptom('Alice', 'fever')
    
    symptom = 'fever'
    diagnosis = predict_diagnosis(symptom)
    print(f"Predicted Diagnosis: {diagnosis}")
    
    provide_advice(diagnosis)
    provide_health_education(diagnosis)
    schedule_appointment('Alice', '2024-10-15', '10:00 AM')
    view_appointments('Alice')
    set_medication_reminder('Alice', 'Ibuprofen', 1)
    view_medication_reminders('Alice')
    save_profiles_to_json()
